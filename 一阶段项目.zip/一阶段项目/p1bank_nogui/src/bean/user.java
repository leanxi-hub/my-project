package bean;

public class user {
	public String name;
	public String leve;
	public String username;
	public String password;
	public String tellphon;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLeve() {
		return leve;
	}
	public void setLeve(String leve) {
		this.leve = leve;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTellphon() {
		return tellphon;
	}
	public void setTellphon(String tellphon) {
		this.tellphon = tellphon;
	}
	public user(String name, String leve, String username, String password, String tellphon) {
		super();
		this.name = name;
		this.leve = leve;
		this.username = username;
		this.password = password;
		this.tellphon = tellphon;
	}
	@Override
	public String toString() {
		return "����:"+name+",�绰:"+tellphon+",ϵͳ��¼��:"+username+",����:"+password+",����:"+leve;
	}
	
}