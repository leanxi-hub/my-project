package dataconte;

import java.util.ArrayList;
import java.util.Scanner;

import bean.user;

public class checkpower {
	public static boolean check(String power) {
		int l=power.length();
		Scanner in =new Scanner(System.in);
//		if(!power.substring(l-1, l).equals(";")) 
		if(!power.endsWith(";")){
			System.out.println("����';'��β");
			return false;
		}
		ArrayList<user> userlist=linksql.getuserlist();
		String[] s=power.split(";");
		l =s.length;
		int tag=0;
		int erron=0;
		for(int i=0;i<l;i++) {
			for(user u:userlist) {
				if(u.getUsername().equals(s[i])&&u.getLeve().equals("������")) {
					tag++;
					break;
				}else {
					erron=i;
				}
			}
		}
		if(tag==l) {
			return true;
		}else {
			System.out.println("��"+erron+"�����ݳ��������");
			in.nextLine();
			return false;
		}
	}
}
