package dataconte;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.comp;
import bean.user;

public class linksql {
	static String driverclass="com.mysql.jdbc.Driver";
	static Connection conn=null;
	static PreparedStatement pre=null;
	static ResultSet re=null;
	static String url="jdbc:mysql://127.0.0.1:3306/p1bank";
	static String user="root";
	static String password="root";
	public static void saveuser(user u) {
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="insert into user(name,leve,username,password,tellphon) values(?,?,?,?,?)";
			pre=conn.prepareStatement(sql);
			pre.setString(1, u.getName());
			pre.setString(2, u.getLeve());
			pre.setString(3, u.getUsername());
			pre.setString(4, u.getPassword());
			pre.setString(5, u.getTellphon());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("���ӳɹ�>>>");
			}
			else{
				System.out.println("����ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static ArrayList<user> getuserlist(){
		ArrayList<user> userlist=new ArrayList<user>();
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="select name,leve,username,password,tellphon from user";
			pre=conn.prepareStatement(sql);
			re=pre.executeQuery();
			while(re.next()){
				String name=re.getString("name");
				String leve=re.getString("leve");
				String username=re.getString("username");
				String password=re.getString("password");
				String tellphon=re.getString("tellphon");
				userlist.add(new user(name, leve, username, password, tellphon));
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return userlist;
	}
	public static void savecomp(comp c) {
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="insert into comp(comname,leve,msg,bhb,money,upusername,uptime,power,state) values(?,?,?,?,?,?,?,?,?)";
			pre=conn.prepareStatement(sql);
			pre.setString(1, c.getComname());
			pre.setString(2, c.getLeve());
			pre.setString(3, c.getMsg());
			pre.setString(4, c.getBhb());
			pre.setString(5, c.getMoney());
			pre.setString(6, c.getUpusername());
			pre.setString(7, c.getUptime());
			pre.setString(8, c.getPower());
			pre.setString(9, c.getState());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("���ӳɹ�>>>");
			}
			else{
				System.out.println("����ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static ArrayList<comp> getcomplist(){
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
		ArrayList<comp> complist=new ArrayList<comp>();
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="select head,comname,leve,msg,bhb,money,upusername,uptime,state,power,hqjl,yhqr from comp";
			pre=conn.prepareStatement(sql);
			re=pre.executeQuery();
			while(re.next()){
				String head=re.getString("head");
				String comname=re.getString("comname");
				String leve=re.getString("leve");
				String msg=re.getString("msg");
				String bhb=re.getString("bhb");
				String money=re.getString("money");
				String upusername=re.getString("upusername");
				String uptime=re.getString("uptime");
				String state=re.getString("state");
				String power=re.getString("power");
				int hqjl=Integer.parseInt(re.getString("hqjl"));
				String yhqr=re.getString("yhqr");
				complist.add(new comp(head, comname, leve, msg, bhb, money, upusername, uptime, state, yhqr, hqjl, power));
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return complist;
	}
	public static void deletecomp(comp c) {
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="delete from comp where comname=?";
			pre=conn.prepareStatement(sql);
			pre.setString(1, c.getComname());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("ɾ���ɹ�>>>");
			}
			else{
				System.out.println("ɾ��ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static void updatacomp_state4(comp c) {
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
//		public String stata;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="update comp set head=?,state=?,yhqr=? where comname=?";
			pre=conn.prepareStatement(sql);
			pre.setString(1, c.getHead());
			pre.setString(2, c.getState());
			pre.setString(3, c.getYhqr());
			pre.setString(4, c.getComname());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("�޸ĳɹ�>>>");
			}
			else{
				System.out.println("�޸�ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static void updatacomp_state5(comp c) {
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
//		public String stata;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="update comp set state=?,money=? where comname=?";
			pre=conn.prepareStatement(sql);
			pre.setString(1, c.getState());
			pre.setString(2, c.getMoney());
			pre.setString(3, c.getComname());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("�޸ĳɹ�>>>");
			}
			else{
				System.out.println("�޸�ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static void updatacomp_state9(comp c) {
//		public String comname;
//		public String leve;
//		public String msg;
//		public String bhb;
//		public String money;
//		public String upusername;
//		public String uptime;
//		public String stata;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			String sql="update comp set state=? ,hqjl=? ,yhqr=? where comname=?";
			pre=conn.prepareStatement(sql);
			pre.setString(1, c.getState());
			pre.setString(2, String.valueOf(c.getHqjl()));
			pre.setString(3, c.getYhqr());
			pre.setString(4, c.getComname());
			int result=pre.executeUpdate();
			if(result>0){
				System.out.println("�޸ĳɹ�>>>");
			}
			else{
				System.out.println("�޸�ʧ��<<<");
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static void savetxttosql(ArrayList<comp> complist) {
		for(comp c:complist) {
			try {
//				String comname;
//				String leve;
//				String msg;
//				String bhb;
//				String money;
//				String upusername;
//				String uptime;
//				String state;
//				String head;
				Class.forName(driverclass);
				conn=DriverManager.getConnection(url, user, password);
				String sql="insert into comp(comname,leve,msg,bhb,money,upusername,uptime,state,head,power) values(?,?,?,?,?,?,?,?,?,?)";
				pre=conn.prepareStatement(sql);
				pre.setString(1, c.getComname());
				pre.setString(2, c.getLeve());
				pre.setString(3, c.getMsg());
				pre.setString(4, c.getBhb());
				pre.setString(5, c.getMoney());
				pre.setString(6, c.getUpusername());
				pre.setString(7, c.getUptime());
				pre.setString(8, c.getState());
				pre.setString(9, c.getHead());
				pre.setString(10, c.getPower());
				int result=pre.executeUpdate();
				if(result>0){
					System.out.println("���ӳɹ�>>>");
					}
				else{
					System.out.println("����ʧ��<<<");
					}
				} catch (Exception e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
				}
			}
		}
}
