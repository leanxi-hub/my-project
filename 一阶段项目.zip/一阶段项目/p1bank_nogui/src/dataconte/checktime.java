package dataconte;

public class checktime {
	public static boolean checktimetrue(String time) {
		String year=time.substring(0, 4);
		String month=time.substring(4, 6);
		String day=time.substring(6, 8);
		int d=Integer.parseInt(day);
		if(d<1) {
			return true;
		}
		switch (month) {
		case "01":
			if(d>31) {
				return true;
			}
			break;
		case "03":
			if(d>31) {
				return true;
			}
			break;
		case "04":
			if(d>30) {
				return true;
			}
			break;
		case "05":
			if(d>31) {
				return true;
			}
			break;
		case "06":
			if(d>30) {
				return true;
			}
			break;
		case "07":
			if(d>31) {
				return true;
			}
			break;
		case "08":
			if(d>31) {
				return true;
			}
			break;
		case "09":
			if(d>30) {
				return true;
			}
			break;
		case "10":
			if(d>31) {
				return true;
			}
			break;
		case "11":
			if(d>30) {
				return true;
			}
			break;
		case "12":
			if(d>31) {
				return true;
			}
			break;
		}
		if(Integer.parseInt(time.substring(3, 4))==0) {
			if(Integer.parseInt(year)%400!=0) {
				if(month.equals("02")&&d>28) {
					return true;
				}
			}else {
				if(month.equals("02")&&d>29) {
					return true;
				}
			}
		}
		else {
			if(Integer.parseInt(year)%4!=0) {
				if(month.equals("02")&&d>28) {
					return true;
				}
			}else {
				if(month.equals("02")&&d>29) {
					return true;
				}
			}
		}
		return false;
	}
}
