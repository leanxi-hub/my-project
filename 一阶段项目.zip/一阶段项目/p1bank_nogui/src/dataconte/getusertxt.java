package dataconte;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import bean.comp;
import bean.user;

public class getusertxt {
	public static void getusetxt(){
		String name;
		String username;
		String password;
		String leve;
		String tellphon;
		String line;
		Scanner in = new Scanner(System.in);
		ArrayList<user> userlist=new ArrayList<user>();
		FileReader reader;
		try {
			reader = new FileReader("./user.txt");
			BufferedReader br = new BufferedReader(reader);
			while ((line = br.readLine()) != null) {
				String[] s=line.split(":");
				if(s.length<5) {
					System.out.println(line);
					System.out.println("������Ϣ�д������");
					in.nextLine();
				}
				name=s[0];
				username=s[1];
				tellphon=s[2];
				password=s[3];
				leve=s[4];
			linksql.saveuser(new user(name, leve, username, password, tellphon));
			}
			for(user u:userlist) {
				System.out.println(u.name+""+u.leve);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void getcomptxt(){
		String line;
		String head;
		String comname;
		String leve;
		String msg;
		String bhb;
		String money;
		String upusername;
		String uptime;
		String state;
		String power;
		Scanner in = new Scanner(System.in);
		ArrayList<comp> complist=new ArrayList<comp>();
		FileReader reader;
		try {
			reader = new FileReader("./save.txt");
			BufferedReader br = new BufferedReader(reader);
			while ((line = br.readLine()) != null) {
			System.out.println(line);
				String[] s=line.split(":");
				if(s.length==11) {
					upusername=s[0]+":"+s[1];
					uptime=s[2];
					head=s[3]+":";
					bhb=s[4];
					comname=s[5];
					money=s[6];
					leve=s[7];
					msg=s[8];
					state=s[9];
					power=s[10];
					complist.add(new comp(head, comname, leve, msg, bhb, money, upusername, uptime, state, power));
				}else {
					System.out.println(line);
					System.out.println("������Ϣ�д������");
					in.nextLine();
				}
			}
		linksql.savetxttosql(complist);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
//		getusetxt();
		getcomptxt();
	}
}
