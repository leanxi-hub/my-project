package dataconte;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;

import bean.comp;
import state.state_1;
import state.state_4;

public class satesaveandget {
	public static void save(){
		File fp=new File("./seting.txt");
		PrintWriter pfp;
		try {
			pfp = new PrintWriter(fp);
			pfp.print(state_1.xdflg);
			pfp.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void getseting() {
		String line;
		FileReader reader;
		try {
			reader = new FileReader("./seting.txt");
			BufferedReader br = new BufferedReader(reader);
			while ((line = br.readLine()) != null) {
				state_1.xdflg=Integer.parseInt(line);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void savehycx(){
		File fp=new File("./hycx.txt");
		PrintWriter pfp;
		try {
			pfp = new PrintWriter(fp);
			pfp.print(state_4.times);
			pfp.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void gethycx() {
		String line;
		FileReader reader;
		try {
			reader = new FileReader("./hycx.txt");
			BufferedReader br = new BufferedReader(reader);
			while ((line = br.readLine()) != null) {
				state_4.times=Integer.parseInt(line);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
