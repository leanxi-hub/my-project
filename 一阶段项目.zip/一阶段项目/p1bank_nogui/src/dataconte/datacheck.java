package dataconte;

import java.util.ArrayList;

import bean.comp;
import bean.user;

public class datacheck {
	public static ArrayList<user> userlist=linksql.getuserlist();
	public static ArrayList<comp> complist=linksql.getcomplist();
	public static boolean logincheck(String username,String password) {
		for(user u:userlist) {
			if(u.getUsername().equals(username)&&u.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}
	public static boolean levecheck(String username,String leve) {
		for(user u:userlist) {
			if(u.getUsername().equals(username)&&u.getLeve().equals(leve)) {
				return true;
			}
		}
		return false;
	}
	public static String gettellphon(String username) {
		flashlist();
		for(user u:userlist) {
			if(u.getUsername().equals(username)) {
				return u.getTellphon();
			}
		}
		return null;
	}
	public static String getname(String username) {
		flashlist();
		for(user u:userlist) {
			if(u.getUsername().equals(username)) {
				return u.getName();
			}
		}
		return null;
	}
	public static void flashlist() {
		userlist=linksql.getuserlist();
		complist=linksql.getcomplist();
	}
	public static ArrayList<comp> getcomplist(){
		flashlist();
		return complist;
	}
	
}
