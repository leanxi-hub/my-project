package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.model.pojo.ResponseAjax;
import com.dfrz.model.pojo.ResponseAjax;
import com.dfrz.model.pojo.UserBean;
import com.dfrz.service.ILoginService;
import com.dfrz.service.impl.LoginServiceImpl;
import com.google.gson.Gson;

/**
 * 验证登录，并使用ajax返回登陆情况 登陆后根据用户职位进入不同页面
 * 
 * @author yh
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		ILoginService lsi = new LoginServiceImpl();
		Gson gs = new Gson();
		ResponseAjax res = new ResponseAjax();
		if ("".equals(username) || username.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("用户名不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(password) || password.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("密码不能为空,请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		List<UserBean> user1 = lsi.login(username, password);
		UserBean user = null;
		for (UserBean u : user1) {
			if (u.getUsername().equals(username)) {
				if (u.getPassword().equals(password)) {
					HttpSession session = request.getSession();
					session.setAttribute("username", username);
					session.setAttribute("password", password);
					user = u;
					break;
				} else {
					break;
				}
			} else {
				break;
			}
		}
		if (user == null) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("用户名或密码输入错误!");
			response.getWriter().print(gs.toJson(res));
			return;
		} else {
			System.out.println(user);
			response.setContentType("application/json;charset=utf-8");
			res.setCod(0);
			res.setMsg("登陆成功!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
	}
}