package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.dao.impl.UserDaoImpl;
import com.dfrz.model.pojo.UserBean;

/**
 * Servlet implementation class AdminUpdatereturnServlet
 */
@WebServlet("/admin/admin_updatereturn")
public class AdminUpdatereturnServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminUpdatereturnServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		UserDaoImpl udi = new UserDaoImpl();
		List<UserBean> users = udi.getUpdateId(id);
		UserBean user = null;
		for (UserBean u : users)
			user = u;
		System.out.println(user);
		if (user.getLevel().equals("系统管理员")) {
			response.sendRedirect("/assetManagement/admin/admin_checkUserList");
			return;
		} else {
			request.setAttribute("userupdate", user);
			request.getRequestDispatcher("/page/admin/admin_update.jsp").forward(request, response);
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
	}

}
