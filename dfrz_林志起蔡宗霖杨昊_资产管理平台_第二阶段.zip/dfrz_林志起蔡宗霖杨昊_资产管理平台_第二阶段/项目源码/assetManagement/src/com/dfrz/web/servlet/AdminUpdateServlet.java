package com.dfrz.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.model.pojo.ResponseAjax;
import com.dfrz.model.pojo.UserBean;
import com.dfrz.service.IAdminUpdateService;
import com.dfrz.service.impl.AdminUpdateServiceImpl;
import com.google.gson.Gson;

/**
 * 更新用户数据
 * 
 * @author yh
 */
@WebServlet("/admin/admin_update")
public class AdminUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		System.out.println("您要修改的用户id为:" + id);
		String password = request.getParameter("password");
		String state = request.getParameter("state");
		String level = request.getParameter("level");
		String city = request.getParameter("city");
		ResponseAjax resajax = new ResponseAjax();
		Gson gs = new Gson();
		if ("".equals(password) || password == null) {
			resajax.setCod(-1);
			resajax.setMsg("密码不能修改为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		if ("".equals(state) || state == null) {
			resajax.setCod(-1);
			resajax.setMsg("工作状态不能修改为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;

		}
		if ("".equals(level) || level == null) {
			resajax.setCod(-1);
			resajax.setMsg("职位不能修改为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;

		}
		if ("".equals(city) || city == null) {
			resajax.setCod(-1);
			resajax.setMsg("公司分部不能修改为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;

		} else {

			UserBean user = new UserBean();
			user.setPassword(password);
			user.setState(state);
			user.setCity(city);
			user.setLevel(level);
			IAdminUpdateService ius = new AdminUpdateServiceImpl();
			ius.update(id, password, level, state, city);
			resajax.setCod(0);
			resajax.setMsg("修改成功!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
	}
}
