package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.model.pojo.Asset;
import com.dfrz.model.pojo.ResponseAjax;
import com.dfrz.service.IUserPurchaseAssetService;
import com.dfrz.service.impl.UserPurchaseAssetServiceImpl;
import com.google.gson.Gson;

/**
 * 用户购买资产
 * 
 * @author yh
 */
@WebServlet("/UserPurchaseAssetServlet")
public class UserPurchaseAssetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("utf-8");

//		User_assetlistService uas = new User_assetelistServiceImpl();

//		String financialCoding = request.getParameter("financialCoding");
//		String assetsEncodingstr = request.getParameter("assetsEncoding");
//		int assetsEncoding = Integer.parseInt(assetsEncodingstr);
//		String productSerialNumstr = request.getParameter("productSerialNum");
//		int productSerialNum = Integer.parseInt(productSerialNumstr);
//		String assetClasses = request.getParameter("assetClasses");
//		String assetName = request.getParameter("assetName");
//		String specifications = request.getParameter("specifications");
//		String storageTime = request.getParameter("storageTime");
//		String unit = request.getParameter("unit");
//		String numstr = request.getParameter("num");
//		int num = Integer.parseInt(numstr);
//		String unitPricestr = request.getParameter("unitPrice");
//		int unitPrice = Integer.parseInt(unitPricestr);
//		String division = request.getParameter("division");
//		String assetState = request.getParameter("assetState");

//		Gson gs = new Gson();
//
//		boolean result = uas.purchaseAsset(financialCoding, assetsEncoding, productSerialNum, assetClasses, assetName,
//				specifications, storageTime, unit, num, unitPrice, division, assetState);
//		System.out.println(result);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String financialCoding = request.getParameter("financialCoding");
		String assetsEncoding = request.getParameter("assetsEncoding");
		String productSerialNumstr = request.getParameter("productSerialNum");
		int productSerialNum = Integer.parseInt(productSerialNumstr);
		String assetClasses = request.getParameter("assetClasses");
		String assetName = request.getParameter("assetName");
		String specifications = request.getParameter("specifications");
		String storageTime = request.getParameter("storageTime");
		String unit = request.getParameter("unit");
		String numstr = request.getParameter("num");
		int num = Integer.parseInt(numstr);
		String unitPricestr = request.getParameter("unitPrice");
		int unitPrice = Integer.parseInt(unitPricestr);
		String division = request.getParameter("division");
		String assetState = request.getParameter("assetState");
		Gson gs = new Gson();
		ResponseAjax res = new ResponseAjax();
		if ("".equals(financialCoding) || financialCoding.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("财政编码格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(assetsEncoding) || assetsEncoding.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("资产编码格式不符，请重新输入!");

			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(productSerialNum) || num == 0) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("产品序列号格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(assetClasses) || assetClasses.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("资产类别格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(assetName) || assetName.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("资产名称格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(specifications) || specifications.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("规格型号格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(storageTime) || storageTime.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("入库时间格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(unit) || unit.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("单位格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(num) || num == 0) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("数量资产名称格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(unitPrice) || unitPrice == 0) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("单价格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		if ("".equals(division) || division.equals(null)) {
			response.setContentType("application/json;charset=utf-8");
			res.setCod(-1);
			res.setMsg("分部格式不符，请重新输入!");
			response.getWriter().print(gs.toJson(res));
			return;
		}
		IUserPurchaseAssetService uas = new UserPurchaseAssetServiceImpl();

		List<Asset> asset1 = uas.returnPurchaseAdd(assetName);
		boolean s = true;
		Asset asset = new Asset();
		for (Asset a : asset1) {
			if (a.getAssetName().equals(assetName)) {
				s = false;
				response.setContentType("application/json;charset=utf-8");
				res.setCod(-1);
				res.setMsg("该资产已存在，请重新输入!");
				response.getWriter().print(gs.toJson(res));
				return;
			}
		}
		if (s == true) {
			asset.setFinancialCoding(financialCoding);
			asset.setAssetsEncoding(assetsEncoding);
			asset.setProductSerialNum(productSerialNum);
			asset.setAssetClasses(assetClasses);
			asset.setAssetName(assetName);
			asset.setSpecifications(specifications);
			asset.setStorageTime(storageTime);
			asset.setUnit(unit);
			asset.setNum(num);
			asset.setUnitPrice(unitPrice);
			asset.setDivision(division);
			uas.purchaseAsset(financialCoding, assetsEncoding, productSerialNum, assetClasses, assetName,
					specifications, storageTime, unit, num, unitPrice, division);
			response.setContentType("application/json;charset=utf-8");
			res.setCod(0);
			res.setMsg("资产入库成功");
			response.getWriter().print(gs.toJson(res));
			return;
		}
	}

}
