package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.dao.impl.UserDaoImpl;
import com.dfrz.model.pojo.UserBean;

/**
 * 查看用户列表
 * 
 * @author yh
 */
@WebServlet("/admin/admin_checkUserList")
public class AdminCheckUserListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 * public UserListServlet() { super(); // TODO Auto-generated constructor stub }
	 * 
	 * /**
	 * 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 * response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		UserDaoImpl udi = new UserDaoImpl();
		List<UserBean> list = udi.getAllUser();
		System.out.println(list);
		HttpSession session = request.getSession();
		session.setAttribute("userdata", list);
		request.getRequestDispatcher("/page/admin/admin_checkUserList.jsp").forward(request, response);
	}

}
