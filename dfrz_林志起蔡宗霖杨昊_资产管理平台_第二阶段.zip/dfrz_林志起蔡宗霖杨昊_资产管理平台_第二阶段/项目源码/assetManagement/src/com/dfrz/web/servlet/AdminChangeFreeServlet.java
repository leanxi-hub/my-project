package com.dfrz.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.service.IAdminChangeService;
import com.dfrz.service.impl.AdminChangeServiceImpl;

/**
 * 将资产状态转为闲置
 * 
 * @author lzq
 */
@WebServlet("/AdminChangeFreeServlet")
public class AdminChangeFreeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 获取页面信息
		String cardNumStr = request.getParameter("cardNum");
		int cardNum = Integer.parseInt(cardNumStr);

		// 修改资产状态为闲置

		IAdminChangeService AC = new AdminChangeServiceImpl();
		AC.changeFree(cardNum);

		// 跳转页面
		request.getRequestDispatcher("./AdminFindChangeAssetServlet").forward(request, response);
	}

}
