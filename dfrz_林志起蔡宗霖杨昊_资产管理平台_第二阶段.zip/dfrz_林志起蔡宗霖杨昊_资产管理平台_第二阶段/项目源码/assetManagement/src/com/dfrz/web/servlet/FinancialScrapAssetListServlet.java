package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IFinancialCheckAssetListService;
import com.dfrz.service.impl.FinancialCheckAssetListServiceImpl;

/**
 * 查询报废资产
 * 
 * @author lzq
 */
@WebServlet("/FinancialScrapAssetListServlet")
public class FinancialScrapAssetListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FinancialScrapAssetListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 查询状态为报废的资产
		IFinancialCheckAssetListService FCAL = new FinancialCheckAssetListServiceImpl();
		List<Asset> ScrapAsset = FCAL.searchScrapAsset();

		// 将报废资产存放到session上
		HttpSession session = request.getSession();
		session.setAttribute("assets", ScrapAsset);

		// 跳转页面
		request.getRequestDispatcher("page/financial/financial_scrapList.jsp").forward(request, response);
	}

}
