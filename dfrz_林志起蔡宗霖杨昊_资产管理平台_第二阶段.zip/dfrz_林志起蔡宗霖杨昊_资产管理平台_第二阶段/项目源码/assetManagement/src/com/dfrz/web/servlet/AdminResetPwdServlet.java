package com.dfrz.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.service.IAdminUpdateService;
import com.dfrz.service.impl.AdminUpdateServiceImpl;

/**
 * 重置密码
 * 
 * @author yh
 */
@WebServlet("/admin/admin_resetPwd")
public class AdminResetPwdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		IAdminUpdateService ids = new AdminUpdateServiceImpl();
		ids.resetPswd(id);
		System.out.println("您要修改的用户id为:" + id);
		response.sendRedirect("/assetManagement/admin/admin_checkUserList");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);
	}

}
