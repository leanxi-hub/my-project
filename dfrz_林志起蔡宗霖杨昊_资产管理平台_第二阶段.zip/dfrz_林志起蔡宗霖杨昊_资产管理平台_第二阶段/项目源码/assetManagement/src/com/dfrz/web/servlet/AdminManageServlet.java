package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.model.pojo.UserBean;
import com.dfrz.service.ILoginService;
import com.dfrz.service.impl.LoginServiceImpl;

/**
 * 管理员登录管理
 * 
 * @author yh
 */
@WebServlet("/admin/admin_manage")
public class AdminManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminManageServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		/*
		 * HttpSession session = request.getSession(); String username = (String)
		 * session.getAttribute("username"); String password = (String)
		 * session.getAttribute("password"); System.out.println(username); ILoginService
		 * lsi = new LoginServiceImpl(); List<UserBean> user1 = lsi.login(username,
		 * password); System.out.println(user1); for (UserBean u : user1) {
		 * System.out.println(u); switch (u.getLevel()) { case "系统管理员":
		 * session.setAttribute("admin", user1);
		 * request.getRequestDispatcher("/page/admin/nav-bar-admin.jsp").forward(
		 * request, response); return; case "财务人员": session.setAttribute("financial",
		 * user1);
		 * request.getRequestDispatcher("/page/financial/financial.jsp").forward(
		 * request, response); return; case "普通员工": session.setAttribute("user", user1);
		 * request.getRequestDispatcher("/page/user/user.jsp").forward(request,
		 * response); return; } } }
		 */
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/* doPost(request, response); */
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		String password = (String) session.getAttribute("password");
		System.out.println(username);
		ILoginService lsi = new LoginServiceImpl();
		List<UserBean> user1 = lsi.login(username, password);
		System.out.println(user1);
		for (UserBean u : user1) {
			System.out.println(u);
			System.out.println(u.getLevel());
			switch (u.getLevel()) {
			case "系统管理员":
				session.setAttribute("admin", user1);
				response.sendRedirect("../page/admin/admin.jsp");
				return;
			case "财务人员":
				session.setAttribute("financial", user1);
				response.sendRedirect("../page/financial/financial.jsp");
				return;
			case "普通员工":
				session.setAttribute("user", user1);
				response.sendRedirect("../page/user/user.jsp");
				return;
			}
		}
	}
}
