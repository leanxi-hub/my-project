package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IFinancialTransfersService;
import com.dfrz.service.impl.FinancialTransfersServiceImpl;

/**
 * 查询调拨去往该分部的资产状态为调出方已确认的资产列表
 * 
 * @author lzq
 */
@WebServlet("/FinancialTransfersInConfirmServlet")
public class FinancialTransfersInConfirmServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 获取页面信息
		String division = request.getParameter("division");
		System.out.println(division);

		// 查询所属分部资产状态为发起调拨的资产列表
		IFinancialTransfersService FT = new FinancialTransfersServiceImpl();
		List<Asset> FindTransferAsset = FT.searchToTransferAsset(division);

		// 将所属分部资产状态为发起调拨的资产存放到session上
		HttpSession session = request.getSession();
		session.setAttribute("assets", FindTransferAsset);

		// 跳转页面
		response.sendRedirect("page/financial/financial_transfersInConfirm.jsp");
	}

}
