package com.dfrz.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class filter1
 */
@WebFilter(urlPatterns = {"/*"})
public class filter1 implements Filter {
	private String encode="UTF-8";
	/**
	 * Default constructor.
	 */
	public filter1() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req=(HttpServletRequest )request;
		HttpServletResponse res=(HttpServletResponse )response;
			System.out.println("编码过滤器");
			req.setCharacterEncoding(encode);
			//设置响应类型
			res.setCharacterEncoding(encode);
			res.setContentType("application/json;charset="+encode);
			//将请求与响应传递给下个过滤器
			chain.doFilter(req, res);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		encode=fConfig.getInitParameter("encode");
		if(encode==null){
			encode="UTF-8";
		}
	}

}
