package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IAdminTransfersService;
import com.dfrz.service.impl.AdminTransfersServiceImpl;

/**
 * 查询闲置的出库资产表
 * 
 * @param cardNum:卡片编号
 * @param billingDate:财务入账日期
 * @param certificateNum:凭证号
 * @param financialCoding:财务编码
 * @param assetsEncoding:资产编码
 * @param productSerialNum:产品序列号
 * @param assetClasses:资产类别
 * @param assetName:资产名称
 * @param specifications:规格型号
 * @param storageTime:入库时间
 * @param unit:单位
 * @param num:数量
 * @param unitPrice:单价
 * @param depositoryMan:保管人
 * @param useMan:使用人
 * @param division:分部
 * @param assetState：资产状态
 * @param storageState：入库状态
 * 
 * @return 资产集合
 * @author lzq
 */
@WebServlet("/AdminFindFreeAndNoInStorageAssetServlet")
public class AdminFindFreeAndNoInStorageAssetServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 查询状态为闲置的出库资产
		IAdminTransfersService AT = new AdminTransfersServiceImpl();
		List<Asset> FindFreeAndNoInStorageAsset = AT.searchFreeAndNoInStorageAsset();

		// 将闲置的出库资产存放到session上
		HttpSession session = request.getSession();
		session.setAttribute("assets", FindFreeAndNoInStorageAsset);

		// 跳转页面
		response.sendRedirect("page/admin/admin_transfersFreeAsset.jsp");
	}

}
