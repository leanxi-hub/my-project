package com.dfrz.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.service.IFinancialDeleteService;
import com.dfrz.service.impl.FinancialDeleteServiceImpl;

/**
 * 财务销账
 * 
 * @author lzq
 */
@WebServlet("/FinancialDeleteServlet")
public class FinancialDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 获取页面数据
		String cardNumStr = request.getParameter("cardNum");
		int cardNum = Integer.parseInt(cardNumStr);
		// 把报废的资产销账
		IFinancialDeleteService FD = new FinancialDeleteServiceImpl();
		FD.toDeleteScrapAsset(cardNum);
		// 跳转页面
		request.getRequestDispatcher("./FinancialScrapAssetListServlet").forward(request, response);

	}
}