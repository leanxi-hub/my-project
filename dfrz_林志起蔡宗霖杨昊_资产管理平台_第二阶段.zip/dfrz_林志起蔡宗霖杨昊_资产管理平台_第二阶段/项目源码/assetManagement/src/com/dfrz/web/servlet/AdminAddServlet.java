package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.dao.IUserDao;
import com.dfrz.dao.impl.UserDaoImpl;
import com.dfrz.model.pojo.ResponseAjax;
import com.dfrz.model.pojo.UserBean;
import com.dfrz.service.ILoginService;
import com.dfrz.service.impl.LoginServiceImpl;
import com.google.gson.Gson;

/**
 * 添加用户
 * 
 * @author yh
 */
@WebServlet("/admin/admin_add")
public class AdminAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String level = request.getParameter("level");
		String gender = request.getParameter("gender");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		Gson gs = new Gson();
		ResponseAjax resajax = new ResponseAjax();
		if ("".equals(username) || null == username) {
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(-1);
			resajax.setMsg("用户名不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		if ("".equals(level) || null == level) {
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(-1);
			resajax.setMsg("职位不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		if ("".equals(gender) || null == gender) {
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(-1);
			resajax.setMsg("性别不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		if ("".equals(city) || null == city) {
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(-1);
			resajax.setMsg("公司分部不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		if ("".equals(state) || null == state) {
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(-1);
			resajax.setMsg("工作状态不能为空，请重新输入!");
			response.getWriter().print(gs.toJson(resajax));
			return;
		}
		ILoginService lsi = new LoginServiceImpl();
		List<UserBean> user1 = lsi.returnAdd(username);
		boolean s = true;
		UserBean user = new UserBean();
		for (UserBean u : user1) {
			if (u.getUsername().equals(username)) {
				s = false;
				response.setContentType("application/json;charset=utf-8");
				resajax.setCod(-1);
				resajax.setMsg("该用户已存在，请重新输入!");
				response.getWriter().print(gs.toJson(resajax));
				return;
			}
		}
		if (s == true) {
			user.setUsername(username);
			user.setLevel(level);
			user.setGender(gender);
			user.setCity(city);
			user.setState(state);
			IUserDao udi = new UserDaoImpl();
			udi.Adduser(username, level, gender, state, city);
			response.setContentType("application/json;charset=utf-8");
			resajax.setCod(0);
			resajax.setMsg("添加成功");
			response.getWriter().print(gs.toJson(resajax));
		}
	}

}
