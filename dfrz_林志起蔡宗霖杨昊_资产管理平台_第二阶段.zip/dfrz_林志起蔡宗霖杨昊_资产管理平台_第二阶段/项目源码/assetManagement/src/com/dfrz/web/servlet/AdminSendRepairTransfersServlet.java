package com.dfrz.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IAdminTransfersService;
import com.dfrz.service.impl.AdminTransfersServiceImpl;

/**
 * 填写调拨信息
 * 
 * @author lzq
 */
@WebServlet("/AdminSendRepairTransfersServlet")
public class AdminSendRepairTransfersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 判断cardNum
		String cardNumStr = request.getParameter("cardNum");
		int cardNum = Integer.parseInt(cardNumStr);
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> assets = assetDao.getAssetByCardNum(cardNum);

		Asset asset = null;
		for (Asset a : assets) {
			asset = a;
		}
		request.setAttribute("TransfersAssetByCardNum", asset);
		request.getRequestDispatcher("page/admin/admin_sendRepair.jsp").forward(request, response);
		return;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 获取页面信息
		String cardNumStr = request.getParameter("cardNum");
		int cardNum = Integer.parseInt(cardNumStr);
		String transferDivision = request.getParameter("transferDivision");

		// 填写调拨信息(调拨去往分部和资产状态)

		IAdminTransfersService AT = new AdminTransfersServiceImpl();
		AT.send(cardNum, transferDivision);

		// 跳转页面
		request.getRequestDispatcher("./AdminFindRepairAssetServlet").forward(request, response);
	}

}
