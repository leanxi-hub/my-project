package com.dfrz.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfrz.service.IFinancialTransfersService;
import com.dfrz.service.impl.FinancialTransfersServiceImpl;

/**
 * 调出方确认调拨
 * 
 * @author lzq
 */
@WebServlet("/FinancialInConfirmServlet")
public class FinancialInConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
//		response.setContentType("text/html");
//
//		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("utf-8");
//
//		// 判断cardNum
//		String cardNumStr = request.getParameter("cardNum");
//		int cardNum = Integer.parseInt(cardNumStr);
//		IAssetDao assetDao = new AssetDaoImpl();
//
//		List<Asset> assets = assetDao.getAssetByCardNum(cardNum);
//
//		Asset asset = null;
//		for (Asset a : assets) {
//			asset = a;
//		}
//		request.setAttribute("InConfirmAssetByCardNum", asset);
//		request.getRequestDispatcher("page/financial/financial_updateInConfirm.jsp").forward(request, response);
//		return;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 获取页面信息
		String all = request.getParameter("cardNum");
		String cardNumStr = all.split(",")[0];
		int cardNum = Integer.parseInt(cardNumStr);
		System.out.println(cardNum);
		String division = all.split(",")[1];
		System.out.println(division);

		// 修改确认后信息

		IFinancialTransfersService FT = new FinancialTransfersServiceImpl();
		FT.inConfirm(cardNum, division);

		// 跳转页面
		request.getRequestDispatcher("./FinancialTransfersInConfirmServlet").forward(request, response);
	}

}
