package com.dfrz.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBManager {
	private static Connection con;
	private static DataSource dataSource;

	public DBManager() {
	}

	/**
	 * 输入流
	 * 
	 * @return Java.sql.DataSource
	 * @throws SQLException
	 */
	static Properties properties = null;

	final static String filename = "db.properties";

	static {
		properties = new Properties();

		InputStream inputStream = DBManager.class.getClassLoader().getResourceAsStream(filename);
		try {
			properties.load(inputStream);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 获取数据对象
	 * 
	 * @author lzq
	 */
	public static Connection getCon() {
		if (con == null) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				con = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/assetscont?characterEncoding=utf8&useSSL=false&serverTimezone=UTC&rewriteBatchedStatements=true",
						"root", "a379150");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return con;
	}

	/**
	 * 从c3p0连接池中获取数据源对象
	 * 
	 * @author lzq
	 */
	public static Connection getC3p0Con() {
		ComboPooledDataSource tempDataSource = new ComboPooledDataSource();
		try {
			tempDataSource.setDriverClass("com.mysql.cj.jdbc.Driver");
			tempDataSource.setJdbcUrl(
					"jdbc:mysql://localhost:3306/assetscont?characterEncoding=utf8&useSSL=false&serverTimezone=UTC&rewriteBatchedStatements=true");
			tempDataSource.setUser("root");
			tempDataSource.setPassword("a379150");// 密码
			tempDataSource.setCheckoutTimeout(3000);
			tempDataSource.setMaxStatementsPerConnection(100);
			tempDataSource.setInitialPoolSize(15);
			tempDataSource.setMaxPoolSize(50);
			tempDataSource.setMinPoolSize(10);
			dataSource = tempDataSource;
			con = dataSource.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	/**
	 * Connection关闭
	 * 
	 * @author lzq
	 */
	public static void closeConnection() {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		con = null;
	}

	/**
	 * PreparedStatement关闭
	 * 
	 * @author lzq
	 */
	public static void closePreparedStatement(PreparedStatement pstm) {
		if (pstm != null) {
			try {
				pstm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		pstm = null;
	}

	/**
	 * Statement关闭
	 * 
	 * @author lzq
	 */
	public static void closeStatement(Statement stm) {
		if (stm != null) {
			try {
				stm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		stm = null;
	}

	/**
	 * ResultSet关闭
	 * 
	 * @author lzq
	 */
	public static void closeResultSet(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		rs = null;
	}

	/**
	 * 测试连接
	 * 
	 * @author yh
	 */
	public static void main(String[] args) throws SQLException {
		// Connection c = DBManager.getCon();
		Connection c = DBManager.getC3p0Con();
		if (c != null) {
			System.out.print("ok");
		} else {
			System.out.print("fail");
		}

	}
}
