package com.dfrz.model.pojo;

/**
 * ajax
 * 
 * @author yh
 *
 */
public class ResponseAjax {
	private int cod;
	private String msg;

	public ResponseAjax(int cod, String msg) {
		super();
		this.cod = cod;
		this.msg = msg;
	}

	public int getCod() {
		return cod;
	}

	public ResponseAjax() {
		super();
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
