package com.dfrz.model.pojo;

/**
 * 资产类
 * 
 * @author lzq
 *
 */
public class Asset {
	private Integer cardNum;// 卡片编号
	private String billingDate;// 财务入账日期
	private String certificateNum;// 凭证号
	private String financialCoding;// 财务编码
	private String assetsEncoding;// 资产编码
	private Integer productSerialNum;// 产品序列号
	private String assetClasses;// 资产类别
	private String assetName;// 资产名称
	private String specifications;// 规格型号
	private String storageTime;// 入库时间
	private String unit;// 单位
	private Integer num;// 数量
	private Integer unitPrice;// 单价
	private String depositoryMan;// 保管人
	private String useMan;// 使用人
	private String division;// 分部
	private String assetState;// 资产状态
	private String storageState;// 入库状态
	private String transferDivision;// 调拨去往分部

	public Integer getCardNum() {
		return cardNum;
	}

	public void setCardNum(Integer cardNum) {
		this.cardNum = cardNum;
	}

	public String getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

	public String getCertificateNum() {
		return certificateNum;
	}

	public void setCertificateNum(String certificateNum) {
		this.certificateNum = certificateNum;
	}

	public String getFinancialCoding() {
		return financialCoding;
	}

	public void setFinancialCoding(String financialCoding) {
		this.financialCoding = financialCoding;
	}

	public String getAssetsEncoding() {
		return assetsEncoding;
	}

	public void setAssetsEncoding(String assetsEncoding) {
		this.assetsEncoding = assetsEncoding;
	}

	public Integer getProductSerialNum() {
		return productSerialNum;
	}

	public void setProductSerialNum(Integer productSerialNum) {
		this.productSerialNum = productSerialNum;
	}

	public String getAssetClasses() {
		return assetClasses;
	}

	public void setAssetClasses(String assetClasses) {
		this.assetClasses = assetClasses;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getSpecifications() {
		return specifications;
	}

	public void setSpecifications(String specifications) {
		this.specifications = specifications;
	}

	public String getStorageTime() {
		return storageTime;
	}

	public void setStorageTime(String storageTime) {
		this.storageTime = storageTime;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public Integer getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Integer unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getDepositoryMan() {
		return depositoryMan;
	}

	public void setDepositoryMan(String depositoryMan) {
		this.depositoryMan = depositoryMan;
	}

	public String getUseMan() {
		return useMan;
	}

	public void setUseMan(String useMan) {
		this.useMan = useMan;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getAssetState() {
		return assetState;
	}

	public void setAssetState(String assetState) {
		this.assetState = assetState;
	}

	public String getStorageState() {
		return storageState;
	}

	public void setStorageState(String storageState) {
		this.storageState = storageState;
	}

	public String getTransferDivision() {
		return transferDivision;
	}

	public void setTransferDivision(String transferDivision) {
		this.transferDivision = transferDivision;
	}

	@Override
	public String toString() {
		return "Asset [cardNum=" + cardNum + ", billingDate=" + billingDate + ", certificateNum=" + certificateNum
				+ ", financialCoding=" + financialCoding + ", assetsEncoding=" + assetsEncoding + ", productSerialNum="
				+ productSerialNum + ", assetClasses=" + assetClasses + ", assetName=" + assetName + ", specifications="
				+ specifications + ", storageTime=" + storageTime + ", unit=" + unit + ", num=" + num + ", unitPrice="
				+ unitPrice + ", depositoryMan=" + depositoryMan + ", useMan=" + useMan + ", division=" + division
				+ ", assetState=" + assetState + ", storageState=" + storageState + ", transferDivision="
				+ transferDivision + "]";
	}

}
