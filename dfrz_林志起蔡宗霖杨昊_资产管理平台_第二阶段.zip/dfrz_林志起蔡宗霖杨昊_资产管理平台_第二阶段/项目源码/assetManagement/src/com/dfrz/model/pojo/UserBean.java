package com.dfrz.model.pojo;

/**
 * 用户类
 * 
 * @author yh
 *
 */

public class UserBean {
	private int id;
	private String username;
	private String password;
	private String state;
	private String gender;
	private String city;
	private String level;

	@Override
	public String toString() {
		return id + "\t" + username + "\t " + password + "\t" + state + "\t" + gender + "\t" + city + "\t " + level;
	}

	public UserBean() {
		super();
	}

	public UserBean(int id, String username, String password, String state, String gender, String city, String level) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.state = state;
		this.gender = gender;
		this.city = city;
		this.level = level;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

}