package com.dfrz.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.IUserDao;
import com.dfrz.model.pojo.UserBean;
import com.dfrz.utils.DBManager;

public class UserDaoImpl implements IUserDao {
	// private static ArrayList<UserBean> userListData = new ArrayList<UserBean>();
	String username;
	String password;

	/**
	 * 根据信息添加用户对象
	 * 
	 * @param username 用户名
	 * @param level    职业
	 * @param gender   性别
	 * @param state    工作状态
	 * @param city     公司分部
	 * @return result 是否成功
	 * @author yh
	 */

	public boolean Adduser(String username, String level, String gender, String state, String city) {
		boolean result = false;
		Connection con = null;//
		Statement stm = null;//
		try {
			con = DBManager.getC3p0Con();// 创建链接

			String sql = "insert into user(user_name,user_level,user_gender,user_state,user_city)values('" + username
					+ "','" + level + "','" + gender + "','" + state + "','" + city + "')";

			stm = con.createStatement();// 创建stm
			int i = stm.executeUpdate(sql);
			if (i > 0)
				result = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBManager.closeStatement(stm);
			DBManager.closeConnection();
		}
		return result;
	}

	/**
	 * 得到用户所有数据
	 * 
	 * @return user 用户对象
	 * @author yh
	 */
	public List<UserBean> getAllUser() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<UserBean> users = new ArrayList<UserBean>();

		try {

			con = DBManager.getC3p0Con();

			String sql = "select * from user ";

			pstm = con.prepareStatement(sql);

			// pstm.setInt(1, id);

			rs = pstm.executeQuery();// 结果集

			// 将结果集的数据封装到list中
			UserBean user = null;
			while (rs.next()) {
				user = new UserBean();
				user.setId(rs.getInt("user_id"));
				user.setUsername(rs.getString("user_name"));
				user.setPassword(rs.getString("user_pswd"));
				user.setLevel(rs.getString("user_level"));
				user.setGender(rs.getString("user_gender"));
				user.setState(rs.getString("user_state"));
				user.setCity(rs.getString("user_city"));
				users.add(user);
			}
		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return users;

	}

	/**
	 * 根据id回填修改页面的信息
	 * 
	 * @return users对象
	 * @author yh
	 */
	public List<UserBean> getUpdateId(int id) {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<UserBean> users = new ArrayList<UserBean>();

		try {

			con = DBManager.getC3p0Con();

			String sql = "select * from user where user_id=? ";

			pstm = con.prepareStatement(sql);
			pstm.setInt(1, id);

			rs = pstm.executeQuery();// 结果集

			// 将结果集的数据封装到list中
			UserBean user = null;
			while (rs.next()) {
				user = new UserBean();
				user.setId(rs.getInt("user_id"));
				user.setUsername(rs.getString("user_name"));
				user.setPassword(rs.getString("user_pswd"));
				user.setLevel(rs.getString("user_level"));
				user.setGender(rs.getString("user_gender"));
				user.setState(rs.getString("user_state"));
				user.setCity(rs.getString("user_city"));
				users.add(user);
			}
		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return users;

	}

	@Override
	/**
	 * 重置密码
	 * 
	 * @param id：序号
	 * @param password:学生性别
	 * @return 是否成功
	 * @author yh
	 */
	public boolean updateUserByIdAndPswd(int id) {
		boolean result = false;

		Connection con = null;

		PreparedStatement pstm = null;

		try {
			// con=DBManager.getCon();
			con = DBManager.getC3p0Con();

			String sql = "update user set user_pswd=123456 where user_id=?";

			pstm = con.prepareStatement(sql);
			pstm.setInt(1, id);
			int i = pstm.executeUpdate();

			if (i > 0) {
				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

	/**
	 * 根据id修改用户信息
	 * 
	 * @param city：公司分部
	 * @param state:工作状态
	 * @param password:密码
	 * @return 是否成功
	 * @author yh
	 */

	public boolean update(int id, String password, String level, String state, String city) {
		boolean result = false;

		Connection con = null;

		PreparedStatement pstm = null;
		try {
			con = DBManager.getC3p0Con();
			String sql = "update user set user_pswd=?,user_level=?,user_state=?,user_city=? where user_id=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, password);
			pstm.setString(2, level);
			pstm.setString(3, state);
			pstm.setString(4, city);
			pstm.setInt(5, id);
			int i = pstm.executeUpdate();

			if (i > 0) {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally

		{
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;

	}

	@Override
	/**
	 * 根据用户名和密码查询验证登录
	 * 
	 * @param username 用户名
	 * @param password 密码
	 * @return user 用户对象
	 * @author yh
	 */
	public List<UserBean> findUserByUsernameAndPassword(String username, String password) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<UserBean> users = new ArrayList<UserBean>();

		try {

			con = DBManager.getC3p0Con();
			String sql = "select * from user where user_name=? and user_pswd=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, username);
			pstm.setString(2, password);
			rs = pstm.executeQuery();// 结果集
			// 将结果集的数据封装到list中
			UserBean user = null;
			while (rs.next()) {
				user = new UserBean();
				user.setId(rs.getInt("user_id"));
				user.setUsername(rs.getString("user_name"));
				user.setPassword(rs.getString("user_pswd"));
				user.setLevel(rs.getString("user_level"));
				user.setGender(rs.getString("user_gender"));
				user.setState(rs.getString("user_state"));
				user.setCity(rs.getString("user_city"));
				users.add(user);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return users;

	}

	/**
	 * 删除用户，但不能是管理员
	 * 
	 * @return 是否成功 Boolean
	 * @author yh
	 */
	public boolean deleteUser(int id) {
		boolean result = false;

		Connection con = null;

		PreparedStatement pstm = null;

		try {
			// con=DBManager.getCon();
			con = DBManager.getC3p0Con();

			String sql = "delete from user where user_id=?";

			pstm = con.prepareStatement(sql);
			pstm.setInt(1, id);
			int i = pstm.executeUpdate();

			if (i > 0) {
				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

	/**
	 * 根据用户名返回所有用户信息，用来ajax判断
	 * 
	 * @return list对象
	 * @author yh
	 */
	public List<UserBean> returnAdd(String username) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<UserBean> users = new ArrayList<UserBean>();

		try {

			con = DBManager.getC3p0Con();
			String sql = "select * from user where user_name=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, username);
			rs = pstm.executeQuery();// 结果集
			// 将结果集的数据封装到list中
			UserBean user = null;
			while (rs.next()) {
				user = new UserBean();
				user.setId(rs.getInt("user_id"));
				user.setUsername(rs.getString("user_name"));
				user.setPassword(rs.getString("user_pswd"));
				user.setLevel(rs.getString("user_level"));
				user.setGender(rs.getString("user_gender"));
				user.setState(rs.getString("user_state"));
				user.setCity(rs.getString("user_city"));
				users.add(user);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return users;

	}

}
