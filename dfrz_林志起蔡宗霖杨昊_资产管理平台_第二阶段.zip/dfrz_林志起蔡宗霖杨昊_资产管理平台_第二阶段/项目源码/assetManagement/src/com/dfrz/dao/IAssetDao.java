package com.dfrz.dao;

import java.util.List;

import com.dfrz.model.pojo.Asset;

/**
 * 资产表的dao
 * 
 *
 */
public interface IAssetDao {
	/**
	 * 查询整个资产列表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> selectAsset();

	/**
	 * 根据入账日期查询未入账的资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findNoInBillAsset();

	/**
	 * 根据资产状态查询状态为报废的资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findScrapAsset();

	/**
	 * 根据卡片编号获取资产列表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> getAssetByCardNum(int cardNum);

	/**
	 * 填写入账信息
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public boolean toUpdateBill(int cardNum, String billingDate, String certificateNum);

	/**
	 * 销账资产
	 * 
	 * @author lzq
	 */
	public boolean deleteScrapAsset(int cardNum);

	/**
	 * 添加购买资产
	 * 
	 * @author yh
	 */
	public boolean purchaseAsset(String financialCoding, String assetsEncoding, int productSerialNum,
			String assetClasses, String assetName, String specifications, String storageTime, String unit, int num,
			int unitPrice, String division);

	/**
	 * 根据资产名查找资产
	 * 
	 * @return 资产集合
	 * @author yh
	 */
	public List<Asset> returnPurchaseAdd(String assetName);

	/**
	 * 查询闲置的出库资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findFreeAndNoInStorageAsset();

	/**
	 * 查询返修资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findRepairAsset();

	/**
	 * 填写调拨发起信息
	 * 
	 * @param cardNum:卡片编号
	 * @param assetState:资产状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return boolean
	 * @author lzq
	 */
	public boolean toSend(int cardNum, String transferDivision);

	/**
	 * 查询所属分部资产状态为发起调拨的资产列表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findTransfersOutConfirm(String division);

	/**
	 * 查询调拨去往该分部的资产状态为调出方已确认的资产列表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findTransfersInConfirm(String division);

	/**
	 * 修改资产状态为调出方已确认
	 * 
	 * @author lzq
	 */
	public boolean toOutConfirm(int cardNum);

	/**
	 * 修改资产状态为闲置 ，修改入库状态为入库 ，修改分部为调拨去往分部， 修改调拨去往分部为无
	 * 
	 * @author lzq
	 */
	public boolean toInConfirm(int cardNum, String division);

	/**
	 * 查询需要替换的资产表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findChangeAsset();

	/**
	 * 修改状态为闲置
	 * 
	 * @author lzq
	 */
	public boolean toChangeFree(int cardNum);

	/**
	 * 修改状态为返修
	 * 
	 * @author lzq
	 */
	public boolean toChangeRepair(int cardNum);

	/**
	 * 修改状态为报废
	 * 
	 * @author lzq
	 */
	public boolean toChangeScrap(int cardNum);

}
