package com.dfrz.dao;
/**
 * 学生表的dao
 * 
 * @author yh
 */

import java.util.List;

import com.dfrz.model.pojo.UserBean;

public interface IUserDao {

	/**
	 * 根据用户名和密码验证登录
	 * 
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return user 用户对象
	 * @author yh
	 */
	public List<UserBean> findUserByUsernameAndPassword(String username, String password);

	/**
	 * 重置密码
	 * 
	 * @param id：序号
	 * @param password:学生性别
	 * @return 是否成功
	 * @author yh
	 */

	public boolean updateUserByIdAndPswd(int id);

	/**
	 * 根据 id修改用户信息
	 * 
	 * @param city：公司分部
	 * @param state:工作状态
	 * @return 是否成功
	 * @author yh
	 */

	public boolean update(int id, String password,String levle, String state, String city);

	/**
	 * 添加用户 密码为默认密码
	 * 
	 * @param city：公司分部
	 * @param state:工作状态
	 * @return 是否成功
	 * @author yh
	 */
	public boolean Adduser(String username, String level, String gender, String state, String city);

	/**
	 * 根据id回填修改页面的信息
	 * 
	 * @return users对象
	 * @author yh
	 */
	public List<UserBean> getUpdateId(int id);

	/**
	 * 得到用户所有数据
	 * 
	 * @return user 用户对象
	 * @author yh
	 */
	public List<UserBean> getAllUser();
	/**
	 * 删除用户，但不能是管理员
	 * 
	 * @return 是否成功 Boolean
	 * @author yh
	 */
	public boolean deleteUser(int id);
	/**
	 * 根据用户名返回所有用户信息，用来ajax判断
	 * 
	 * @return list对象
	 * @author yh
	 */
	public List<UserBean> returnAdd(String username);
}
