package com.dfrz.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.IAssetDao;
import com.dfrz.model.pojo.Asset;
import com.dfrz.utils.DBManager;

public class AssetDaoImpl implements IAssetDao {

	/**
	 * 查询整个资产列表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 *
	 * @return 资产集合
	 * @author lzq
	 */
	@Override
	public List<Asset> selectAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 根据入账时间查询资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findNoInBillAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where billing_date='00000000'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 根据资产状态查询状态为报废的资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findScrapAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='报废'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 根据卡片编号获取资产列表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	@Override
	public List<Asset> getAssetByCardNum(int cardNum) {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where card_num=?";

			pstm = con.prepareStatement(sql);
			pstm.setInt(1, cardNum);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 填写入账信息
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * 
	 * @return boolean
	 * @author lzq
	 */
	public boolean toUpdateBill(int cardNum, String billingDate, String certificateNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set billing_date=?,certificate_num=?where card_num=?";

			pstm = con.prepareStatement(sql);
			pstm.setString(1, billingDate);
			pstm.setString(2, certificateNum);
			pstm.setInt(3, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;

	}

	/**
	 * 销账资产
	 * 
	 * @author lzq
	 */
	@Override
	public boolean deleteScrapAsset(int cardNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "delete from asset where card_num=?";

			pstm = con.prepareStatement(sql);
			pstm.setInt(1, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}
		return result;
	}

	/**
	 * 根据资产卡号修改状态及所有人
	 * 
	 * @author czl
	 */
	public static boolean upuser_manofasset(int card_num, String depository_man, String user_man, String asset_state,
			String storage_state) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		boolean ret = false;
		con = DBManager.getC3p0Con();
		String sql = "update asset set depository_man=?,use_man=?,asset_state=?,storage_state=?where card_num=?";
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, depository_man);
			pstm.setString(2, user_man);
			pstm.setString(3, asset_state);
			pstm.setString(4, storage_state);
			pstm.setInt(5, card_num);
			int result = pstm.executeUpdate();
			if (result > 0) {
				ret = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}
		return ret;
	}

	public static boolean upusma(String assetsEncoding, String depository_man, String user_man, String asset_state,
			String storage_state) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		boolean ret = false;
		con = DBManager.getC3p0Con();
		String sql = "update asset set depository_man=?,use_man=?,asset_state=?,storage_state=?where assets_encoding=?";
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, depository_man);
			pstm.setString(2, user_man);
			pstm.setString(3, asset_state);
			pstm.setString(4, storage_state);
			pstm.setString(5, assetsEncoding);
			int result = pstm.executeUpdate();
			if (result > 0) {
				ret = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}
		return ret;
	}

	/**
	 * 添加购买资产
	 * 
	 * @author yh
	 */
	public boolean purchaseAsset(String financialCoding, String assetsEncoding, int productSerialNum,
			String assetClasses, String assetName, String specifications, String storageTime, String unit, int num,
			int unitPrice, String division) {
		Connection con = null;

		boolean result = false;
		Statement stm = null;
		try {
			con = DBManager.getC3p0Con();// 创建链接

			String sql = "insert into asset(financial_coding,assets_encoding,product_serialNum,asset_classes,asset_name,specifications,storage_time,unit,num,unit_price,division)values('"
					+ financialCoding + "','" + assetsEncoding + "','" + productSerialNum + "','" + assetClasses + "','"
					+ assetName + "','" + specifications + "','" + storageTime + "','" + unit + "','" + num + "','"
					+ unitPrice + "','" + division + "')";

			stm = con.createStatement();// 创建stm
			int i = stm.executeUpdate(sql);
			if (i > 0)
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.closeStatement(stm);
			DBManager.closeConnection();
		}
		return result;
	}

	/**
	 * 根据资产名称返回资产信息，用来ajax判断
	 * 
	 * @return 资产集合
	 * @author yh
	 */
	public List<Asset> returnPurchaseAdd(String assetName) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();

		try {
			con = DBManager.getC3p0Con();
			String sql = "select * from asset where asset_name=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, assetName);
			rs = pstm.executeQuery();// 结果集
			// 将结果集的数据封装到list中
			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;

	}

	/**
	 * 查询闲置的出库资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findFreeAndNoInStorageAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='闲置' and storage_state='出库'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 查询返修资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findRepairAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='返修'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 填写调拨发起信息
	 * 
	 * @param cardNum:卡片编号
	 * @param assetState:资产状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return boolean
	 * @author lzq
	 */
	public boolean toSend(int cardNum, String transferDivision) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set asset_state=?,transfer_division=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "发起调拨");
			pstm.setString(2, transferDivision);
			pstm.setInt(3, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;

	}

	/**
	 * 查询所属分部资产状态为发起调拨的资产列表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findTransfersOutConfirm(String division) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='发起调拨' and division='" + division + "'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 修改资产状态为调出方已确认
	 * 
	 * @author lzq
	 */
	public boolean toOutConfirm(int cardNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set asset_state=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "调出方已确认");
			pstm.setInt(2, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

	/**
	 * 查询调拨去往该分部的资产状态为调出方已确认的资产列表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findTransfersInConfirm(String division) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='调出方已确认' and transfer_division='" + division + "'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 修改资产状态为闲置 ，修改入库状态为入库 ，修改分部为调拨去往分部， 修改调拨去往分部为无
	 * 
	 * @author lzq
	 */
	public boolean toInConfirm(int cardNum, String division) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set division=?,asset_state=?,storage_state=?,transfer_division=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, division);
			pstm.setString(2, "闲置");
			pstm.setString(3, "入库");
			pstm.setString(4, "无");
			pstm.setInt(5, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;

	}

	/**
	 * 查询需要替换的资产表
	 *
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> findChangeAsset() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		List<Asset> assets = new ArrayList<Asset>();
		try {
			con = DBManager.getC3p0Con();

			String sql = "select * from asset where asset_state='替换'";

			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();// 结果集

			Asset asset = null;
			while (rs.next()) {
				asset = new Asset();
				asset.setCardNum(rs.getInt("card_num"));// 卡片编号
				asset.setBillingDate(rs.getString("billing_date"));// 财务入账日期
				asset.setCertificateNum(rs.getString("certificate_num"));// 凭证号
				asset.setFinancialCoding(rs.getString("financial_coding"));// 财务编码
				asset.setAssetsEncoding(rs.getString("assets_encoding"));// 资产编码
				asset.setProductSerialNum(rs.getInt("product_serialNum"));// 产品序列号
				asset.setAssetClasses(rs.getString("asset_classes"));// 资产类别
				asset.setAssetName(rs.getString("asset_name"));// 资产名称
				asset.setSpecifications(rs.getString("specifications"));// 规格型号
				asset.setStorageTime(rs.getString("storage_time"));// 入库时间
				asset.setUnit(rs.getString("unit"));// 单位
				asset.setNum(rs.getInt("num"));// 数量
				asset.setUnitPrice(rs.getInt("unit_price"));// 单价
				asset.setDepositoryMan(rs.getString("depository_man"));// 保管人
				asset.setUseMan(rs.getString("use_man"));// 使用人
				asset.setDivision(rs.getString("division"));// 分部
				asset.setAssetState(rs.getString("asset_state"));// 资产状态
				asset.setStorageState(rs.getString("storage_state"));// 入库状态
				asset.setTransferDivision(rs.getString("transfer_division"));// 调拨去往分部
				assets.add(asset);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closeResultSet(rs);
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return assets;
	}

	/**
	 * 修改状态为闲置
	 * 
	 * @author lzq
	 */
	public boolean toChangeFree(int cardNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set asset_state=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "闲置");
			pstm.setInt(2, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

	/**
	 * 修改状态为返修
	 * 
	 * @author lzq
	 */
	public boolean toChangeRepair(int cardNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set asset_state=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "返修");
			pstm.setInt(2, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

	/**
	 * 修改状态为报废
	 * 
	 * @author lzq
	 */
	public boolean toChangeScrap(int cardNum) {
		Connection con = null;
		PreparedStatement pstm = null;

		boolean result = false;
		try {
			con = DBManager.getC3p0Con();

			String sql = "update asset set asset_state=?where card_num=?";
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "报废");
			pstm.setInt(2, cardNum);

			int i = pstm.executeUpdate();
			if (i > 0) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.closePreparedStatement(pstm);
			DBManager.closeConnection();
		}

		return result;
	}

}
