package com.dfrz.service.impl;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.UserhovertomecheckService;

public class UserhovertomecheckServiceImpl implements UserhovertomecheckService {
	public boolean checkhover(int card_num,String username) {
		return new AssetDaoImpl().upuser_manofasset(card_num, username, username, "领用","出库");
	}
}
