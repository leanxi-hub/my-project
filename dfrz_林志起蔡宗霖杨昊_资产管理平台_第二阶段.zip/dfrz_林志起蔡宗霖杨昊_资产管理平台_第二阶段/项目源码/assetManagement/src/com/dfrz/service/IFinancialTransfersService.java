package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

/**
 * 财务调拨确认逻辑
 * 
 * @author lzq
 */
public interface IFinancialTransfersService {
	/**
	 * 查询所属分部资产状态为发起调拨的资产列表
	 * 
	 * @author lzq
	 */
	public List<Asset> searchTransferAsset(String division);

	/**
	 * 查询调拨去往该分部的资产状态为调出方已确认的资产列表
	 * 
	 * @author lzq
	 */
	public List<Asset> searchToTransferAsset(String division);

	/**
	 * 修改资产状态为调出方已确认
	 * 
	 * @author lzq
	 */
	public boolean outConfirm(int cardNum);

	/**
	 * 修改资产状态为闲置 ，修改入库状态为入库 ，修改分部为调拨去往分部， 修改调拨去往分部为无
	 * 
	 * @author lzq
	 */
	public boolean inConfirm(int cardNum, String division);
}
