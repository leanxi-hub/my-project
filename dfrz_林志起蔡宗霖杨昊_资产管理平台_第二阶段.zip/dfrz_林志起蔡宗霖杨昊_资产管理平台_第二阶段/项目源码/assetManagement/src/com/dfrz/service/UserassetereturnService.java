package com.dfrz.service;

public interface UserassetereturnService {
	public static boolean assetreturn(String assetsEncoding,String username) {
		return true;
	}
}
