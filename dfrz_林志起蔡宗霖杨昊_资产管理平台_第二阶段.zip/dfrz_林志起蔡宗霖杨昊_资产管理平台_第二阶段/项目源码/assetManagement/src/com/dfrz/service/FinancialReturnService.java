package com.dfrz.service;

public interface FinancialReturnService {
	public static boolean checkreturnassete(String assetsEncoding) {
		return true;
	}
}
