package com.dfrz.service;

/**
 * 管理员修改的接口
 * 
 * @author yh
 *
 */
public interface IAdminUpdateService {
	/**
	 * 重置密码
	 * 
	 * @param
	 * @return Boolean result
	 * @author yh
	 */
	public boolean resetPswd(int id);

	/**
	 * 修改信息
	 * 
	 * @param id：序号
	 * @param password:密码
	 * @param state：工作状态
	 * @param city：公司分部
	 * @return Boolean result
	 * @author yh
	 */
	public boolean update(int id, String password,String level, String state, String city);
}
