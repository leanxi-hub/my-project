package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

public interface UserassetelistService {
	public static List<Asset> getUserasseterlist(String username) {
		return null;
	}
}
