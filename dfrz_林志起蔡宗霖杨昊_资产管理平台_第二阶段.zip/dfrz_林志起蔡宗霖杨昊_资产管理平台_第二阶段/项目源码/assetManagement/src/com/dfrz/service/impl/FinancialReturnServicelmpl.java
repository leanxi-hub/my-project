package com.dfrz.service.impl;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.FinancialReturnService;

public class FinancialReturnServicelmpl implements FinancialReturnService {
	public boolean checkreturnassete(int card_num) {
		return new AssetDaoImpl().upuser_manofasset(card_num, "无", "无", "闲置","入库");
	}
	public boolean changeassete(int card_num) {
		return new AssetDaoImpl().upuser_manofasset(card_num, "无", "无", "替换","出库");
	}
}
