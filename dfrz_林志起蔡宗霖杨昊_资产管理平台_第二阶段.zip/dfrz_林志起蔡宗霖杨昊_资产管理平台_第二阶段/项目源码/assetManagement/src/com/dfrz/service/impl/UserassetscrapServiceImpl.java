package com.dfrz.service.impl;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.UserassetscrapService;

public class UserassetscrapServiceImpl implements UserassetscrapService{
	public boolean scrapasset(int card_num) {
		return new AssetDaoImpl().upuser_manofasset(card_num, "无", "无", "报废","出库");
	}
}
