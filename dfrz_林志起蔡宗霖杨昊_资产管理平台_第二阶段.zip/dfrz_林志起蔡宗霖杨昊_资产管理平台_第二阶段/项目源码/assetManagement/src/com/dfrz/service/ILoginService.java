package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.UserBean;;

/**
 * 用户登录接口
 * 
 * @author yh
 *
 */
public interface ILoginService {

	/**
	 * 验证登录
	 * 
	 * @param username:用户名
	 * @param password:密码
	 * @return UserBean对象 null:登录失败 非空：登录成功
	 * @author yh
	 */
	public List<UserBean> login(String username, String password);

	/**
	 * 根据用户名返回所有用户信息，用来ajax判断
	 * 
	 * @return list对象
	 * @author yh
	 */
	public List<UserBean> returnAdd(String username);
}
