package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

/**
 * 根据卡片编号获取资产逻辑
 * 
 * @author lzq
 *
 */
public interface IGetAssetByCardNumService {
	/**
	 * 根据卡片编号获取资产逻辑
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> toGetAssetByCardNum(int cardNum);
}
