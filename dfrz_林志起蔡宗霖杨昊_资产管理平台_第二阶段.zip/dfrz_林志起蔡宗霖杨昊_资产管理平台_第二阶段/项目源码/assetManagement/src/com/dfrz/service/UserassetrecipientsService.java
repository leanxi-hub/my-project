package com.dfrz.service;

public interface UserassetrecipientsService {
	public static boolean recipientsasset(String assetsEncoding,String username) {
		return true;
	}
}
