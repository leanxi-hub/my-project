package com.dfrz.service.impl;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.IFinancialUpdateBillService;

/**
 * 财务填写入账信息逻辑
 * 
 * @author lzq
 *
 */
public class FinancialUpdateBillServiceImpl implements IFinancialUpdateBillService {
	/**
	 * 填写入账信息
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * 
	 * @return Boolean result
	 * @author lzq
	 */
	public boolean updateBill(int cardNum, String billingDate, String certificateNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toUpdateBill(cardNum, billingDate, certificateNum);
		return result;
	}
}
