package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

/**
 * 管理员替换设备逻辑
 * 
 * @author lzq
 *
 */
public interface IAdminChangeService {
	/**
	 * 查询需要替换的设备
	 * 
	 * @author lzq
	 */
	public List<Asset> searchChangeAsset();

	/**
	 * 修改状态为闲置
	 * 
	 * @author lzq
	 */
	public boolean changeFree(int cardNum);

	/**
	 * 修改状态为返修
	 * 
	 * @author lzq
	 */
	public boolean changeRepair(int cardNum);

	/**
	 * 修改状态为报废
	 * 
	 * @author lzq
	 */
	public boolean changeScrap(int cardNum);
}
