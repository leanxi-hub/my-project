package com.dfrz.service.impl;

import java.util.List;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IAdminChangeService;

/**
 * 管理员替换设备逻辑
 * 
 * @author lzq
 *
 */
public class AdminChangeServiceImpl implements IAdminChangeService {
	/**
	 * 查询需要替换的设备
	 * 
	 * @author lzq
	 */
	public List<Asset> searchChangeAsset() {
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> asset = assetDao.findChangeAsset();
		return asset;
	}

	/**
	 * 修改状态为闲置
	 * 
	 * @author lzq
	 */
	public boolean changeFree(int cardNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toChangeFree(cardNum);
		return result;
	}

	/**
	 * 修改状态为返修
	 * 
	 * @author lzq
	 */
	public boolean changeRepair(int cardNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toChangeRepair(cardNum);
		return result;
	}

	/**
	 * 修改状态为报废
	 * 
	 * @author lzq
	 */
	public boolean changeScrap(int cardNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toChangeScrap(cardNum);
		return result;
	}
}
