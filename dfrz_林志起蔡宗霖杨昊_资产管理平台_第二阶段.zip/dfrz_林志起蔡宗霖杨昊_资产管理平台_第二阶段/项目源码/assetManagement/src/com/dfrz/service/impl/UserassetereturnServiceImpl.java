package com.dfrz.service.impl;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.UserassetereturnService;

public class UserassetereturnServiceImpl implements UserassetereturnService {
	public boolean assetreturn(int card_num,String username) {
		return new AssetDaoImpl().upuser_manofasset(card_num, username, "归还中", "归还中","出库");
	}
}
