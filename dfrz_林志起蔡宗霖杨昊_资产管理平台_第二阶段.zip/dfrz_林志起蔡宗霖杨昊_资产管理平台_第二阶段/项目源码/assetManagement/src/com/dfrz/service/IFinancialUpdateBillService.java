package com.dfrz.service;

/**
 * 财务填写入账信息逻辑
 * 
 * @author lzq
 *
 */
public interface IFinancialUpdateBillService {
	/**
	 * 填写入账信息
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * 
	 * @return Boolean result
	 * @author lzq
	 */
	public boolean updateBill(int cardNum, String billingDate, String certificateNum);
}
