package com.dfrz.service;

public interface UserassetehoverService {
	public static boolean assetehover(String assetsEncoding) {
		return true;
	}
}
