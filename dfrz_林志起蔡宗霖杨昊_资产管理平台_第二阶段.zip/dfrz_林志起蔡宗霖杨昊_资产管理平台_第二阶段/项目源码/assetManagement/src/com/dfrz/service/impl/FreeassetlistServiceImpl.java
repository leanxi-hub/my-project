package com.dfrz.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.Free_assetlistService;

public class FreeassetlistServiceImpl implements Free_assetlistService {
	public List<Asset> getFreeassetlist() {
		List<Asset> assets = new AssetDaoImpl().selectAsset();
		List<Asset> freeassets = new ArrayList<Asset>();
		for (Asset a : assets) {
			if (a.getStorageState().equals("入库") && a.getAssetState().equals("闲置")) {
				freeassets.add(a);
			}
		}
		return freeassets;
	}
}
