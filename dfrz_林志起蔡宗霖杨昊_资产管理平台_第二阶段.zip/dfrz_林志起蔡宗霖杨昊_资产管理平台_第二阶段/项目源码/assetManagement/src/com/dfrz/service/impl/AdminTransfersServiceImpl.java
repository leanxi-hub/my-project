package com.dfrz.service.impl;

import java.util.List;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IAdminTransfersService;

/**
 * 管理员调拨逻辑
 * 
 * @author lzq
 * 
 */
public class AdminTransfersServiceImpl implements IAdminTransfersService {
	/**
	 * 查询闲置的出库资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> searchFreeAndNoInStorageAsset() {
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> assets = assetDao.findFreeAndNoInStorageAsset();
		return assets;
	}

	/**
	 * 查询返修资产表
	 * 
	 * @param cardNum:卡片编号
	 * @param billingDate:财务入账日期
	 * @param certificateNum:凭证号
	 * @param financialCoding:财务编码
	 * @param assetsEncoding:资产编码
	 * @param productSerialNum:产品序列号
	 * @param assetClasses:资产类别
	 * @param assetName:资产名称
	 * @param specifications:规格型号
	 * @param storageTime:入库时间
	 * @param unit:单位
	 * @param num:数量
	 * @param unitPrice:单价
	 * @param depositoryMan:保管人
	 * @param useMan:使用人
	 * @param division:分部
	 * @param assetState：资产状态
	 * @param storageState：入库状态
	 * @param transferDivision:调拨去往分部
	 * 
	 * @return 资产集合
	 * @author lzq
	 */
	public List<Asset> searchRepairAsset() {
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> assets = assetDao.findRepairAsset();
		return assets;
	}

	/**
	 * 填写调拨发起信息
	 * 
	 * @return boolean
	 * @author lzq
	 */
	public boolean send(int cardNum, String transferDivision) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toSend(cardNum, transferDivision);
		return result;
	}
}
