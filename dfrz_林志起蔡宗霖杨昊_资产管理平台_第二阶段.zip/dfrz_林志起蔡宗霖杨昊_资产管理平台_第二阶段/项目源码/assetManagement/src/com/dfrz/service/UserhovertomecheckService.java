package com.dfrz.service;

public interface UserhovertomecheckService {
	public static boolean checkhover(String assetsEncoding,String username) {
		return true;
	}
}
