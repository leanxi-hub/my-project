package com.dfrz.service;

/**
 * 资产销账逻辑
 * 
 * @author lzq
 *
 */
public interface IFinancialDeleteService {
	/**
	 * 资产销账
	 * 
	 * @author lzq
	 *
	 */
	public boolean toDeleteScrapAsset(int cardNum);
}
