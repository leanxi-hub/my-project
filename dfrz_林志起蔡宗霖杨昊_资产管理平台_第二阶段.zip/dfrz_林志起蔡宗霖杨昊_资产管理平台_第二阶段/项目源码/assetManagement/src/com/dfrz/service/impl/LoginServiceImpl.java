package com.dfrz.service.impl;

import java.util.List;

import com.dfrz.dao.IUserDao;
import com.dfrz.dao.impl.UserDaoImpl;
import com.dfrz.model.pojo.UserBean;
import com.dfrz.service.ILoginService;

/**
 * 用户登录接口实现类
 * 
 * @author yh
 *
 */
public class LoginServiceImpl implements ILoginService {

	/**
	 * 验证登录
	 * 
	 * @param username:用户名
	 * @param password:密码
	 * @return UserBean对象 null:登录失败 非空：登录成功
	 * @author yh
	 */
	@Override
	public List<UserBean> login(String username, String password) {

		// 1、调用dao实现数据库验证

		IUserDao userDao = new UserDaoImpl();
		System.out.println(username);
		List<UserBean> users = userDao.findUserByUsernameAndPassword(username, password);
		return users;
	}

	public boolean updatepswd(int id) {
		IUserDao userDao = new UserDaoImpl();
		boolean result = userDao.updateUserByIdAndPswd(id);
		return result;
	}

	/**
	 * 根据用户名返回所有用户信息，用来ajax判断
	 * 
	 * @return list对象
	 * @author yh
	 */
	public List<UserBean> returnAdd(String username) {
		IUserDao userDao = new UserDaoImpl();
		System.out.println(username);
		List<UserBean> users = userDao.returnAdd(username);
		return users;
	}
}
