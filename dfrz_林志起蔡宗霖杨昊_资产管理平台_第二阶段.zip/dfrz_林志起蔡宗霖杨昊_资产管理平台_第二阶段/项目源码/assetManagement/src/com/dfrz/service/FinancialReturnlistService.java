package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

public interface FinancialReturnlistService {
	public static List<Asset> getreturnlist(){
		return null;
	}
}
