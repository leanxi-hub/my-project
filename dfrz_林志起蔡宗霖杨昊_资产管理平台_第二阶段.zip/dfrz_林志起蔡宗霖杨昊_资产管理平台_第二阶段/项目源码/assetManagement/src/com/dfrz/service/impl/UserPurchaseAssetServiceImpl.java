package com.dfrz.service.impl;

import java.util.List;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IUserPurchaseAssetService;

public class UserPurchaseAssetServiceImpl implements IUserPurchaseAssetService {
	/**
	 * 填写添加资产入库
	 * 
	 * 
	 * @return boolean结果
	 * @author yh
	 */
	public boolean purchaseAsset(String financialCoding, String assetsEncoding, int productSerialNum,
			String assetClasses, String assetName, String specifications, String storageTime, String unit, int num,
			int unitPrice, String division) {
		boolean result = false;
		IAssetDao iad = new AssetDaoImpl();
		result = iad.purchaseAsset(financialCoding, assetsEncoding, productSerialNum, assetClasses, assetName,
				specifications, storageTime, unit, num, unitPrice, division);
		return result;
	}

	/**
	 * 根据资产名查找资产
	 * 
	 * @return 资产集合
	 * @author yh
	 */
	public List<Asset> returnPurchaseAdd(String assetName) {
		IAssetDao assetDao = new AssetDaoImpl();
		System.out.println(assetName);
		List<Asset> assets = assetDao.returnPurchaseAdd(assetName);
		return assets;
	}
}
