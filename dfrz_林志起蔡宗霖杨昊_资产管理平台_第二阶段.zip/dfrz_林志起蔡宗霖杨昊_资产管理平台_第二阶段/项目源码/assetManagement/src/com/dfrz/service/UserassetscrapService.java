package com.dfrz.service;

public interface UserassetscrapService {
	public static boolean scrapasset(String assetsEncoding) {
		return true;
	}
}
