package com.dfrz.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.UserassetehoverService;

public class UserassetehoverServiceImpl implements UserassetehoverService {
	public boolean assetehover(int card_num, String username) {
		return new AssetDaoImpl().upuser_manofasset(card_num, username, "移交中", "移交中", "出库");
	}

	public static Asset gethoverasset(int cardNum) {
		Asset as = null;
		for (Asset a : new AssetDaoImpl().selectAsset()) {
			if (a.getCardNum()==cardNum) {
				as = a;
			}
		}
		return as;
	}

	public List<Asset> gethovertomelist(String username) {
		List<Asset> assets = new AssetDaoImpl().selectAsset();
		List<Asset> hovetome = new ArrayList<Asset>();
		for (Asset a : assets) {
			if (a.getAssetState().equals("移交中")) {
				if (a.getDepositoryMan().equals(username)) {
					hovetome.add(a);
				}
			}
		}
		return hovetome;
	}
}
