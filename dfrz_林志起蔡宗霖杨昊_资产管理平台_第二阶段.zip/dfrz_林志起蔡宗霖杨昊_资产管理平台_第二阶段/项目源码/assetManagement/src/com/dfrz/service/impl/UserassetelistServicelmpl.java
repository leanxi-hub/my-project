package com.dfrz.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.UserassetelistService;

public class UserassetelistServicelmpl implements UserassetelistService {
	public List<Asset> getUserasseterlist(String username) {
		List<Asset> assets = new AssetDaoImpl().selectAsset();
		List<Asset> userassets = new ArrayList<Asset>();
		for (Asset a : assets) {
			if (a.getUseMan().equals(username) && a.getAssetState().equals("领用")) {
				userassets.add(a);
			}
		}
		return userassets;
	}
}
