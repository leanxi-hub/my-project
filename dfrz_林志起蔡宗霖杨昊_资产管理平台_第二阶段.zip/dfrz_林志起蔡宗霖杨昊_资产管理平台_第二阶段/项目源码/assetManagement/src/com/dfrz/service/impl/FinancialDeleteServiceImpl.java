package com.dfrz.service.impl;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.IFinancialDeleteService;

/**
 * 资产销账逻辑
 * 
 * @author lzq
 *
 */
public class FinancialDeleteServiceImpl implements IFinancialDeleteService {
	/**
	 * 资产销账
	 * 
	 * @author lzq
	 */
	public boolean toDeleteScrapAsset(int cardNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.deleteScrapAsset(cardNum);
		return result;
	}
}
