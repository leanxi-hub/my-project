package com.dfrz.service.impl;

import java.util.List;

import com.dfrz.dao.IAssetDao;
import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.IFinancialTransfersService;

/**
 * 财务调拨确认逻辑
 * 
 * @author lzq
 */
public class FinancialTransfersServiceImpl implements IFinancialTransfersService {
	/**
	 * 查询所属分部资产状态为发起调拨的资产列表
	 * 
	 * @author lzq
	 */
	public List<Asset> searchTransferAsset(String division) {
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> assets = assetDao.findTransfersOutConfirm(division);
		return assets;
	}

	/**
	 * 查询调拨去往该分部的资产状态为调出方已确认的资产列表
	 * 
	 * @author lzq
	 */
	public List<Asset> searchToTransferAsset(String division) {
		IAssetDao assetDao = new AssetDaoImpl();

		List<Asset> assets = assetDao.findTransfersInConfirm(division);
		return assets;
	}

	/**
	 * 修改资产状态为调出方已确认
	 * 
	 * @author lzq
	 */
	public boolean outConfirm(int cardNum) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toOutConfirm(cardNum);
		return result;

	}

	/**
	 * 修改资产状态为闲置 ，修改入库状态为入库 ，修改分部为调拨去往分部， 修改调拨去往分部为无
	 * 
	 * @author lzq
	 */
	public boolean inConfirm(int cardNum, String division) {
		IAssetDao assetDao = new AssetDaoImpl();

		boolean result = assetDao.toInConfirm(cardNum, division);
		return result;
	}
}
