package com.dfrz.service;

import java.util.List;

import com.dfrz.model.pojo.Asset;

public interface IUserPurchaseAssetService {
	public static List<Asset> getUserasseterlist(String user_name) {
		return null;
	}

	/**
	 * 填写添加资产入库
	 * 
	 * 
	 * @return boolean结果
	 * @author yh
	 */
	public boolean purchaseAsset(String financialCoding, String assetsEncoding, int productSerialNum,
			String assetClasses, String assetName, String specifications, String storageTime, String unit, int num,
			int unitPrice, String division);

	/**
	 * 根据资产名查找资产
	 * 
	 * @return 资产集合
	 * @author yh
	 */
	public List<Asset> returnPurchaseAdd(String assetName);
}
