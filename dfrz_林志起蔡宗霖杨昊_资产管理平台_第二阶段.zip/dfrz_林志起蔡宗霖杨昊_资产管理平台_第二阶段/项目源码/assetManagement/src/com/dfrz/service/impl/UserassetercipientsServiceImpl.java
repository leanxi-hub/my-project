package com.dfrz.service.impl;


import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.service.UserassetrecipientsService;

public class UserassetercipientsServiceImpl implements UserassetrecipientsService {
	public boolean recipientsasset(int card_num,String username) {
		return new AssetDaoImpl().upuser_manofasset(card_num, username, username,"领用","出库");
	}
}
