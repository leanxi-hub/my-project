package com.dfrz.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.dfrz.dao.impl.AssetDaoImpl;
import com.dfrz.model.pojo.Asset;
import com.dfrz.service.FinancialReturnlistService;

public class FinancialReturnlistServicelmpl implements FinancialReturnlistService {
	public List<Asset> getreturnlist() {
		AssetDaoImpl assdao = new AssetDaoImpl();
		List<Asset> allassets = assdao.selectAsset();
		List<Asset> returnlist = new ArrayList<Asset>();
		for (Asset a : allassets) {
			if (a.getAssetState().equals("归还中")) {
				returnlist.add(a);
			}
		}
		return returnlist;
	}
}
