package com.dfrz.service.impl;

import com.dfrz.dao.IUserDao;
import com.dfrz.dao.impl.UserDaoImpl;
import com.dfrz.service.IAdminUpdateService;

/**
 * 管理员修改的接口实现类
 * 
 * @author yh
 *
 */
public class AdminUpdateServiceImpl implements IAdminUpdateService {
	/**
	 * 重置密码
	 * 
	 * @param
	 * @return Boolean result
	 * @author yh
	 */
	@Override
	public boolean resetPswd(int id) {
		// TODO Auto-generated method stub
		IUserDao userDao = new UserDaoImpl();
		boolean result = userDao.updateUserByIdAndPswd(id);
		return result;
	}

	/**
	 * 修改信息
	 * 
	 * @param id：序号
	 * @param password:密码
	 * @param state：工作状态
	 * @param city：公司分部
	 * @return Boolean result
	 * @author yh
	 */
	public boolean update(int id, String password,String level, String state, String city) {
		IUserDao userDao = new UserDaoImpl();
		boolean result = userDao.update(id, password, level,state, city);
		return result;
	}
}
